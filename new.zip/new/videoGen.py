import os
import shutil


def fVideoGen(duration):
	#f = open('input.txt','w')



	files = os.listdir('./media/cleanedImages')
	files = ['./media/cleanedImages/'+i for i in files]

	# print(files)
	for j,i in enumerate(files):
		fp = open('ffmpeg1.txt','r')
		print(i)
		a = fp.readline()[:-1]+i+fp.readline()[:-1]+str(duration*25)+fp.readline()[:-1]+str(j)+fp.readline() #dont take \n from ffmpeg1.txt so use [:-1]
		# print(a)
		os.system(a)
		fp.close()

	#concat all files

	#create mylist.txt
	a = "file \'./media/videoChunks/"
	f = open('mylist.txt','w')
	for i in os.listdir('./media/videoChunks'):
		f.write(a+i+'\'\n')
	f.close()

	os.system("ffmpeg -f concat -safe 0 -i mylist.txt -c copy ./media/videos/finalOutput.mp4")		   


# fVideoGen(5)