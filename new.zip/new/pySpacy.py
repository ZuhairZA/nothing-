import spacy
# from spacy import displacy
import operator


nlp = spacy.load('en_core_web_md')
entities = ['GPE','PERSON','PRODUCT','NORP','FAC','ORG','LOC','EVENT','WORK_OF_ART']
removalList = ['\n\n\n','\n\n','\n','',' ','.']

def fSpacy(title, text):
	titleTags = []
	textTags = []
	videoTags = []

	docTitle = nlp(title)
	for ent in docTitle.ents:
		if ent.label_ in entities and ent.text not in ['',' ']:
			titleTags.append(ent.text)
	#         print(ent.text, ent.start_char, ent.end_char, ent.label_)

	doc = nlp(text)
	for ent in doc.ents:
		if ent.text not in videoTags:
			videoTags.append(ent.text)            

	tagDict = {ent.text.lower():0 for ent in doc.ents}
	# displacy.render(doc, style='ent',jupyter=True)
			  
	for ent in doc.ents:
		if ent.label_ in entities and ent.text not in ['',' ']:

			tagDict[ent.text.lower()] += 1
	#         print(ent.text, ent.start_char, ent.end_char, ent.label_)
			
			
	sortedDict = sorted(tagDict.items(), key=operator.itemgetter(1))
	sortedDict.reverse()

	for i in sortedDict:
		if i[0] not in removalList and i[1] >= 3:
			textTags.append(i[0])


	return titleTags,textTags,videoTags