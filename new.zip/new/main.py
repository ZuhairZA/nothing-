from pyNewspaper import fNewspaper
from audioGen import AudioGen
from pageImageDownload import instaTwitter
from selenium import webdriver
import os
from pySpacy import fSpacy
from googleImageDownload import fGoogleImageDownload,cleanImages
from videoGen import fVideoGen
import math
import shutil

media = ['article_images/insta', 'article_images/newspaperImages' ,'article_images/twitter' , 'article_audio', 'cleanedImages', 'videoChunks', 'videos/insta', 'videos/twitter', 'videos/normal']


def fFlush():
	shutil.rmtree('media')
	for i in media:
		os.makedirs('media/'+i)

browser = webdriver.Chrome()

def main():
	url = 'https://www.ndtv.com/entertainment/spot-ranbir-kapoor-in-alia-bhatts-pic-with-the-girls-umm-no-brownie-points-this-is-easy-1883866?pfrom=home-topstory'
	articleDict = fNewspaper(url)
	print('got articleDict')
	duration = AudioGen(articleDict['text'],'hi')
	print('duration is ',duration)
	os.system('ffmpeg -ss 1 -t '+str(duration)+' -i ./background/piano.mp3 ./media/article_audio/background.mp3')
	os.system('ffmpeg -i ./media/article_audio/background.mp3 -i ./media/article_audio/ttsAudio.mp3 -filter_complex amerge -ac 2 -c:a libmp3lame -q:a 4 ./media/article_audio/finalAudio.mp3')
	instaTwitter(browser, articleDict['html'])
	titleTags, textTags, videoTags = fSpacy(articleDict['title'], articleDict['text'])
	fGoogleImageDownload(titleTags, textTags)
	cleanImages()
	imageDuration = math.ceil(duration/len(os.listdir('./media/cleanedImages/')))
	fVideoGen(imageDuration)
	os.system('ffmpeg -i ./media/videos/finalOutput.mp4 -i ./media/article_audio/finalAudio.mp3 -codec copy -shortest finalVideo.mp4')
	fFlush()

main()