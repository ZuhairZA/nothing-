from google_images_download import google_images_download
from PIL import Image
import os

maxsize = (640, 480)
count = 0


def cleanImages():
	global count
	for i in os.listdir('./media/article_images'):
		for j in os.listdir('./media/article_images/'+i):
			img = Image.open('./media/article_images/'+i+'/'+j).convert('RGB')

			tn_image = img.thumbnail(maxsize, Image.ANTIALIAS)

			img_w, img_h = img.size
			background = Image.new('RGBA', (640, 480), (0, 0, 0, 255))
			bg_w, bg_h = background.size
			offset = ((bg_w - img_w) // 2, (bg_h - img_h) // 2)
			background.paste(img, offset)
			backgroundJPG = background.convert('RGB')
			backgroundJPG.save('./media/cleanedImages/'+str(count)+'.jpg')

			count += 1            


def fGoogleImageDownload(titleTags, textTags):
	response = google_images_download.googleimagesdownload()
	tags1 = ''
	tags2 = ''
	for i in titleTags:
		tags1 += i+' '
	tags1 = tags1[:-1]    # having a space at end of search tag crashes code
	for i in textTags:
		tags2 += i+' '
	tags2 = tags2[:-1]
	tags = tags1 + ', ' + tags2

	paths = response.download({"keywords":tags,"limit":4,"output_directory":"./media/article_images", "size":"medium"})

		#get all images in one folder

	


