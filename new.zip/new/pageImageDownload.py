from selenium import webdriver
import cv2
import numpy as np
import os
import re

# follow = cv2.imread('follow.png',0)
# comment = cv2.imread('comment.png',0)

# browser = webdriver.Chrome()

def instaTwitter(browser, html):
	insta = re.findall(r'instagram.com/p/([A-Za-z0-9]+)/',html)
	tweet = re.findall(r'twitter.com\/([A-Za-z0-9_]+)/status/(\d+)',html)
	insta = set(insta)
	tweet = set(tweet)
	instaLinks = ['https://www.instagram.com/p/'+i for i in insta]
	twitterLinks = ['https://www.twitter.com/'+i[0]+'/status/'+i[1] for i in tweet]

	try:
		for j,i in enumerate(instaLinks):
			os.system('youtube-dl -o ./media/videos/insta/'+str(j)+'.mp4 '+i)
		for j,i in enumerate(twitterLinks):
			os.system('youtube-dl -o ./media/videos/twitter/'+str(j)+'.mp4 '+i)
	except:
		print('')

	for j,i in enumerate(instaLinks):
		browser.get(i)
		browser.execute_script("document.body.style.zoom='75%'")
		browser.save_screenshot('./media/article_images/insta/'+str(j)+'.png')
		cropInsta(j)

	for j,i in enumerate(twitterLinks):
		browser.get(i)
		browser.execute_script("document.body.style.zoom='75%'")
		browser.save_screenshot('./media/article_images/twitter/'+str(j)+'.png')


def cropInsta(n):

	img = cv2.imread('./media/article_images/insta/'+str(n)+'.png',0)
	img1 = cv2.imread('./media/article_images/insta/'+str(n)+'.png')
	img = img[60:620,0:1010]
	img1 = img1[60:620,0:1010]

	x,y = img.shape
	count = 0
	left , top, right, bottom = 0,0,0,0
	a = 0
	colList = list()
	for i in range(x):
		for j in range(y):
			if img[i,j] != 250:
				a = 1
				break
		if a == 0:
				#print('white')
				colList.append(0)
		else:
				#print('black')
				colList.append(1)
				a = 0
	top = colList.index(1)
	bottom = colList[top:].index(0) + top
	rowList = list()
	a = 0
	for i in range(y):
		for j in range(top, bottom):
			if img[j,i] != 250:
				a = 1
				break
		if a == 0:
				#print('white')
				rowList.append(0)
		else:
				#print('black')
				rowList.append(1)
				a = 0
	left = rowList.index(1)
	right = rowList[left:].index(0) + left
	cv2.imwrite('./media/article_images/insta/'+str(n)+'.png', img1[top:bottom, left:right])


# def cropTwitter():
# 	im = cv2.imread('ttt.png',0)
# 	res = cv2.matchTemplate(im,follow,cv2.TM_CCOEFF_NORMED)
# 	threshold = 0.9
# 	loc = np.where( res >= threshold)
# 	print(loc)
# 	topx = loc[0][0] - follow.shape[0]
# 	topy = loc[1][0] + follow.shape[1] + 10

# 	res = cv2.matchTemplate(im,comment,cv2.TM_CCOEFF_NORMED)
# 	threshold = 0.9
# 	loc = np.where( res >= threshold)
# 	if len(loc > 1):
# 		loc1.append(loc)
# 	print(loc)
# 	botx = loc[0][0] + comment.shape[0]*2
# 	boty = loc[1][0] - comment.shape[1]*2
# 	print(topx,topy,botx,boty)

# 	cv2.imwrite('crop.png', im[topx:botx, boty:topy])

# follow should be above comment always 