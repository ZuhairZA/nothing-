from googletrans import Translator
from gtts import gTTS
import os
from mutagen.mp3 import MP3
import math
	

def AudioGen(text,lang):

	print(' audio hapening')
	translator = Translator()

	ab = translator.translate(text, dest=lang)

	tts = gTTS(text=ab.text, lang=lang)
	tts.save('./media/article_audio/ttsAudio.mp3')

	audio = MP3("./media/article_audio/ttsAudio.mp3")


	return math.ceil(audio.info.length)
	

