import json
import requests

sources = 'sources=bleacher-report,fox-sports,nfl-news,marca,lequipe,nhl-news,espn-cric-info,football-italia'

def fNewsAPI(sources):

	url = "https://newsapi.org/v2/everything?"+ sources +"&pageSize=100&apiKey=04f2b26c3b05468cb88b0e65aa4e7238"

	response = requests.get(url)
	data = response.json()

	title = data['articles'][0]['title']    # loop over data['articles'] when code is ready
	source = data['articles'][0]['source']['id']
	url = data['articles'][0]['url']
	thumbnail = data['articles'][0]['urlToImage']
	dateOfArticle = data['articles'][0]['publishedAt']