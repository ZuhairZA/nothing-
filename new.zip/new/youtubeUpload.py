
import os
import datetime

def Upload():
  fp = open('UploadDate.txt','r')
  title = fp.readline()
  description = fp.readline()
  category = fp.readline()
  tags = fp.readline()
  recordingDate = datetime.datetime.now()
  playlist = fp.readline()
  location = fp.readline()
  thumbnail = fp.readline()
  fileName = fp.readline()
  
  command = 'youtube-upload --title="'+title+'" --description="'+description+'" --category="'+category+'" --tags="'+tags+'" --recording-date="'+recordingDate+'" --playlist="'+playlist+'" --location="'+location+'" --thumbnail="'+thumbnail+'" '+fileName
  
  os.system(command)




# youtube-upload \
#   --title="A.S. Mutter" 
#   --description="A.S. Mutter plays Beethoven" \
#   --category=Music \
#   --tags="mutter, beethoven" \
#   --recording-date="2011-03-10T15:32:17.0Z" \
#   --playlist "My favorite music" \
#   --location (latitude=VAL,longitude=VAL[,altitude=VAL])  
# --thumbnail (string)
# anne_sophie_mutter.flv
