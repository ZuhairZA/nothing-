from newspaper import Article
import newspaper
import urllib.request
import os
import imagesize
from google_images_download import google_images_download

response = google_images_download.googleimagesdownload()

# url = 'http://bleacherreport.com/articles/2783354-br-staff-predicts-where-lebron-james-will-land-in-nba-free-agency'

def fNewspaper(url):
	articleDict = dict()

	article = Article(url)
	article.download()
	article.parse()

	articleDict['title'] = article.title
	articleDict['html'] = article.html
	articleDict['text'] = article.text
	# articleDict['thumbnail'] = article.top_image
	articleDict['video'] = article.movies

	article.nlp()
	articleDict['tags'] = article.keywords
	articleDict['description'] = article.summary

	# os.mkdir('./media/article_images/newspaperImages')
	# print(article.images)
	for j,i in enumerate(article.images):
		# urllib.request.urlretrieve(i,'./media/article_images/newspaperImages/'+str(j))
		os.chdir('media/article_images/newspaperImages')
		# print(os.getcwd())
		t = "wget -O "+str(j)+' "'+i+'"'
		# print(t)
		os.system(t)
		os.chdir('../../../')
		# print(os.getcwd())
		w, h = imagesize.get('./media/article_images/newspaperImages/'+str(j))
		print(j,w,h)
		if w*h < 200000 or w < 300 or h < 300:
			print('deleting ',j,w,h)
			os.system('del .\\media\\article_images\\newspaperImages\\'+str(j))

	if len(article.movies) > 0:
		for j,i in enumerate(article.movies):
			os.system('youtube-dl -o ./media/videos/normal/'+str(j)+'.mp4 '+i)

	return articleDict

# print(fnewspaper(url))